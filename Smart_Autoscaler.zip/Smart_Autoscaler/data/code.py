import pandas as pd
from prophet import Prophet
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error


df = pd.read_csv("dataset.csv")
df.columns = ['ds', 'y']
df['ds'] = pd.to_datetime(df['ds'])


split_ratio = 0.8
split_index = int(len(df) * split_ratio)

train_df = df.iloc[:split_index]
test_df = df.iloc[split_index:]

model = Prophet(weekly_seasonality=True, daily_seasonality=True)
model.fit(train_df)


future = model.make_future_dataframe(periods= 8640*2, freq='5min')


forecast = model.predict(future)
forecast_output = forecast[['ds', 'yhat']].rename(columns={'ds': 'timestamp', 'yhat': 'value'})
forecast_output.to_csv("forecast_next_2_month.csv", index=False, float_format="%.1f")

predicted = forecast[['ds', 'yhat_upper']].set_index('ds').loc[test_df['ds']]
actual = test_df.set_index('ds')['y']

print(future)
print("*"*12)
print(forecast[:2])
print("*"*12)
print(predicted)
print("*"*12)
mae = mean_absolute_error(actual, predicted['yhat_upper'])


print(f"MAE: {mae:.2f}")


# Plot predictions vs actuals
last_time = actual.index.max()
last_24_hour = last_time - pd.Timedelta(hours=24)

actual_last_hour = actual[actual.index >= last_24_hour]
predicted_last_hour = predicted[predicted.index >= last_24_hour]


plt.figure(figsize=(10, 5))
plt.plot(actual_last_hour.index, actual_last_hour, label='Actual')
plt.plot(predicted_last_hour.index, predicted_last_hour['yhat_upper'], label='Predicted', linestyle='dashed')
plt.title("Last 24 Hour: Actual vs Predicted")
plt.xlabel("Time")
plt.ylabel("Value")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("last_24_hour_prediction1.png")


fig1 = model.plot(forecast)
plt.title('Forecasted Values')
plt.xlabel('Date')
plt.ylabel('Value')
plt.grid(True)
plt.savefig('forecast1.png')


fig2 = model.plot_components(forecast)
plt.savefig('forecast_components1.png')

plt.show()
